# QE Data Grapher

This tool has two parts:
 - createFile.py: Text File Generator
 - xeqt.py: PDF Graph Generator (takes a text file as input)